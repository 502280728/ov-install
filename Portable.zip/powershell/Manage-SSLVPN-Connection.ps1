﻿param(
    [Parameter(Mandatory=$false)]
    [string] $config,
    [Parameter(Mandatory=$false)]
    [string] $authUser,
    [Parameter(Mandatory=$false)]
    [string] $authPass,
    [Parameter(Mandatory=$false)]
    [int] $ensureTapDeviceCount,
    [Parameter(Mandatory=$false)]
    [switch] $status,
    [Parameter(Mandatory=$false)]
    [switch] $async,
    [Parameter(Mandatory=$false)]
    [switch] $autoReconnect = $true,
    [Parameter(Mandatory=$false)]
    [switch] $cleanupOnError,
    [Parameter(Mandatory=$false)]
    $stopConnection
)


$SCRIPT_PATH = Split-Path $MyInvocation.MyCommand.Path

$PREFIX = '..\bin\x64'
if (!(Test-Path $PREFIX)) {
    $PREFIX = '..\bin\x32'
}

if (!(Test-Path $PREFIX)) {
    $PREFIX = '..\bin'
}

$OVPN_BIN = $SCRIPT_PATH+'\'+$PREFIX+'\openvpn.exe'
$TAPINSTALL_BIN = $SCRIPT_PATH+'\'+$PREFIX+'\tapinstall.exe'
$DRIVER_INF = $SCRIPT_PATH+'\'+$PREFIX+'\driver\OemWin2k.inf'

#$config = 'C:\sslvpn-cfg\testfw\testfw.ovpn'
$jobNameBase = "sp-sslvpn"

############################ BEGIN define SpJob ############################
$SpJob = New-Object PSObject -Property @{
    Name = $null
    NetAdapter = $null
    Job = $null
    JobStatus = $null
    Connected = $false
    ConfigFile = $null
    AuthFile = $null
    Errors = [System.Collections.ArrayList]@()
    TapError = $false
}

$SpJob | Add-Member -MemberType ScriptMethod -name getLog -Force -Value {
    Receive-Job -Keep $this.Job
}

############################  END define SpJob  ############################

function SP-Add-TAP-Device() {
    & $TAPINSTALL_BIN install $DRIVER_INF tap0901
}

function SP-Get-TAP-Devices() {
    Get-NetAdapter | Where ComponentID -eq tap0901
}


function SP-Cleanup-Jobs() {
    $jobs = get-job | where Name -Match "^$jobNameBase" | where State -ne "Running"
    if ($jobs.length) {
        $jobs | % {
            Stop-Job $_
            Remove-Job $_
        }
    }
}

function SP-Get-Job-Status() {
    param(
        [Parameter(Mandatory=$true)]
        [System.Management.Automation.Job] $winJob
    )

    $thisJob = $null

    $thisJob = $SpJob.psobject.copy();
    $thisJob.Job = $winJob
    $thisJob.JobStatus = $winJob.State
    $thisJob.Name = $thisJob.Job.Name
    $thisJob.Errors = [System.Collections.ArrayList]@()

    $jobLog = $thisJob.getLog()

    $deviceLine = $([string] $jobLog) -match "TAP-WIN32 device \[(.*)\] opened: \\\\\.\\Global\\(.*)\.tap"
    if ($deviceLine) {
        $thisJob.NetAdapter = $matches[2]
    }

    $cfgLine = $([string] $jobLog) -match "Using config file: (.*?)[`r`n ]+"
    if ($cfgLine) {
        $thisJob.ConfigFile = $matches[1]
    }
    $cfgLine = $([string] $jobLog) -match "Using auth file: (.*?)[`r`n ]+"
    if ($cfgLine) {
        $thisJob.AuthFile = $matches[1]
    }

    $errLine = $jobLog -match "AUTH_FAILED"
    if ($errLine.length) {
        $null = $thisJob.Errors.Add("Auth failed! Please check if your username/password are correct")
    }

    $errLine = $jobLog -match "TLS key negotiation failed to occur within"
    if ($errLine.length) {
        $null = $thisJob.Errors.Add("Could not reach SSLVPN-server. Please check your internet connection!")
    }

    $errLine = $jobLog -match "There are no TAP-Windows adapters on this system."
    if ($errLine.length) {
        $null = $thisJob.Errors.Add($errLine)
        $thisJob.TapError = "no-tap-device"
    }

    $errLine = $jobLog -match "All TAP-Windows adapters on this system are currently in use."
    if ($errLine.length) {
        $null = $thisJob.Errors.Add($errLine)
        $thisJob.TapError = "all-in-use"
    }

    $errLine = $jobLog -match "TUN/TAP interface has been stopped, exiting"
    if ($errLine.length) {
        $null = $thisJob.Errors.Add($errLine)
        $thisJob.TapError = "tap-stopped"
    }

    $errLine = $jobLog -match "TEST ROUTES: 0/0 succeeded"
    if ($errLine.length -gt 10) {
        $null = $thisJob.Errors.Add(($errLine | select -first 1))
        $thisJob.TapError = "test-route-fail"
    }

    $errLine = $jobLog -match "Initialization Sequence Completed With Errors"
    if ($errLine.length) {
        $null = $thisJob.Errors.Add($errLine)
    }

    $errLine = $jobLog -match "fatal error"
    if ($errLine.length) {
        $null = $thisJob.Errors.Add($errLine)
    }


    if ($thisJob.Job.State -eq "Running" -and ($jobLog | select -Last 10) -Match "Initialization Sequence Completed$") {
        $thisJob.Connected = $true
        $thisJob.Errors.Clear()
        $thisJob.TapError = $false
    }

    if ($thisJob.Errors.length -gt 0) {
        $thisJob.JobStatus = "Error"
    }

    $thisJob
}

if ($status) {
    $jobs = get-job | where Name -Match "^$jobNameBase"
    if (!$jobs.length) {
        echo "No SSLVPN-jobs found"
        exit 0;
    }

    $jobs | % {
        SP-Get-Job-Status $_
    }
    exit 0
}

if ($stopConnection) {
    $stopped = 0;
    $stopConnection | % {
        try {
            if ($_ -is [System.Management.Automation.Job]) {
                $spJob = SP-Get-Job-Status $_
                rm $spJob.AuthFile
                Stop-Job $_
                Remove-Job $_
                $stopped++
            } elseif ($_.Job -is [System.Management.Automation.Job]) {
                rm  $_.AuthFile
                Stop-Job $_.Job
                Remove-Job $_.Job
                $stopped++
            } elseif ($_ -is [String]) {
                $jobList = Get-Job -Name $_ | where Name -Match "^$jobNameBase"
                if($jobList.length) {
                    $jobList | % {
                        $spJob = SP-Get-Job-Status $_
                        rm $spJob.AuthFile
                        Stop-Job $_
                        Remove-Job $_
                        $stopped++
                    }
                }
            }
        } catch {
        }
    }
    echo "$($stopped) connections stopped"
    exit 0
}

if ($ensureTapDeviceCount -gt 0) {
    echo "Ensuring that there are $ensureTapDeviceCount TAP devices on this system..."
    for ($i = 0; $i -lt $ensureTapDeviceCount; $i++) {
        if ((SP-Get-TAP-Devices).length -lt $ensureTapDeviceCount) {
            SP-Add-TAP-Device
        }
    }
}

if ($config) {
    if (!$authUser -or !$authPass) {
        Write-Error "Please specify -authUser and -authPass"
        exit 1
    }

    $sb = {
        param(
            [Parameter(Mandatory=$true,Position=0)]
            $OVPN_BIN,
            [Parameter(Mandatory=$true,Position=1)]
            $config,
            [Parameter(Mandatory=$true,Position=2)]
            $authUser,
            [Parameter(Mandatory=$true,Position=3)]
            $authPass,
            [Parameter(Mandatory=$false,Position=4)]
            $autoReconnect
        )
        $cfgPath = Split-Path $config
        echo "Using config file: $config`r`n"

        cd $cfgPath

        $authFile = $cfgPath+'\auth'
        echo "Using auth file: $authFile`r`n"
        Set-Content -Encoding Byte -Path $authFile -Value ([byte[]][char[]] "$authUser`n$authPass")

        $restarts = 0
        do {
            $restarts++;
            & $OVPN_BIN --config $config --auth-user-pass $authFile --hand-window 10 --tls-exit
            echo "exit code of openvpn.exe: $LASTEXITCODE"
            if ($autoReconnect) {
                if ($LASTEXITCODE -eq 0) {
                    if ($restarts -gt 10) {
                        echo "restarted more than 10 times. exiting."
                        $autoReconnect = $false;
                    }
                } else {
                    echo "openvpn stopped. reconnecting..."
                    sleep 1
                }
            } else {
                echo "openvpn stopped. terminating background job."
            }
        } while ($autoReconnect)

    }

    if (!$async) {
        echo "Waiting for successful SSLVPN connect..."
        $errorCount = 0;
        $errorMax = 3
        while ($errorCount -lt $errorMax) {

            echo "Connecting ($($errorCount+1)/$($errorMax))..."
            $job = $jobName = $null;

            $jobName = $jobNameBase+$(get-random)
            $job = Start-Job -Name $jobName -ScriptBlock $sb -ArgumentList $OVPN_BIN,$config,$authUser,$authPass,$autoReconnect
            echo "Background job started with name '$($job.Name)'"

            while ($true) {
                $jobStatus = $null
                $jobStatus = SP-Get-Job-Status $job

                if ($jobStatus.Connected) {
                    SP-Get-Job-Status $job
                    exit 0;
                }
                if ($jobStatus.JobStatus -eq "Error") {
                    if ($jobStatus.TapError -eq "tap-stopped") {
                        echo "The TAP-device has been stopped..."
                        Stop-Job $job
                        Remove-Job $job
                        break;
                    } elseif ($jobStatus.TapError -eq "no-tap-device" -or $jobStatus.TapError -eq "all-in-use") {
                        echo "All TAP-devices are in use. Adding another one..."
                        Stop-Job $job
                        Remove-Job $job
                        SP-Add-TAP-Device
                        break;
                    } elseif ($jobStatus.TapError -eq "test-route-fail") {
                        echo "Setting the routes probably failed. Restarting TAP-device with GUID $($jobStatus.NetAdapter)"
                        Stop-Job $job
                        Remove-Job $job
                        SP-Get-TAP-Devices | Where InterfaceGuid -eq $jobStatus.NetAdapter | Restart-NetAdapter
                        break
                    } else {
                        # non-recoverable error
                        SP-Get-Job-Status $job
                        exit 1
                    }
                }
                sleep 1;
            }

            $errorCount++;
        }
    } else {
        $jobName = $jobNameBase+$(get-random)
        $job = Start-Job -Name $jobName -ScriptBlock $sb -ArgumentList $OVPN_BIN,$config,$authUser,$authPass
        SP-Get-Job-Status $job
        exit 0
    }
}


Write-Error "No command given"
exit 1;
