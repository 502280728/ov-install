# Change Log
All notable changes to this project will be documented in this file.
This project adheres to [Semantic Versioning](http://semver.org/).

## [1.0.0](#1-0-0-2015-06-11) - 2015-06-11

### Added

This Powershell script allows to start/manage/stop SSLVPN-connections by running openvpn.exe in a 
background job.
